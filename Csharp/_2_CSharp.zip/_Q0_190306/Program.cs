﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _Q0_190306
{
    class Program
    {
        // #이 왕복하도록
        static void question01()
        {
            char ch = '#';
            int x = 0;
            int temp = 1;
            Console.SetCursorPosition(0, 12);

            while (true)
            {
                Console.SetCursorPosition(x, 12);
                Console.Write(ch);
                System.Threading.Thread.Sleep(200); // 0.1초 정지
                Console.SetCursorPosition(x, 12);
                Console.Write(' ');

                x = x + temp * 1;
                if (x == 0 || x == 10)
                    temp *= -1;
            }
        }

        // #이 반사 되도록
        //     x++;    x++;    x--;    x--;
        //     y--;    y++;    y++;    y--;
        static void question02()
        {
            char ch = '#';
            int x = 0;
            int y = 12;
            Console.SetCursorPosition(0, 12);
            while (true)
            {
                for (int i = 48; i > 0; i--) //
                {
                    Console.SetCursorPosition(x, y);
                    Console.Write(ch);
                    System.Threading.Thread.Sleep(100); // 0.1초 정지
                    Console.SetCursorPosition(x, y);
                    Console.Write(' ');

                    if (i > 36)
                    {
                        x++;
                        y--;
                    }
                    else if (i > 24)
                    {
                        x++;
                        y++;
                    }
                    else if (i > 12)
                    {
                        x--;
                        y++;
                    }
                    else if (i > 0)
                    {
                        x--;
                        y--;
                    }
                }
            }
        }

        // #이 반사 되도록 다른 문제 
        //     x++;    x++;    x--;    x--;
        //     y--;    y++;    y++;    y--;
        static void question02_1()
        {
            char ch = '#';
            int dirX = 1, dirY = 1;
            int x = 0, y = 12;

            while (true)
            {
                Console.SetCursorPosition(x, y);
                Console.Write(ch);
                System.Threading.Thread.Sleep(100);
                Console.SetCursorPosition(x, y);
                Console.Write("  ");
                x += dirX;
                y += dirY;
                if (x == 24 || x == 0)
                    dirX *= -1;
                if (y == 24 || y == 0)
                    dirY *= -1;
            }


        }

        // question01() 다른 풀이
        static void question11()
        {
            char ch = '#';
            int x = 0;
            Console.SetCursorPosition(0, 12);

            while (true)
            {
                for (int i = 0; i < 20; i++)
                {
                    if (i < 10)
                    {
                        Console.SetCursorPosition(x, 12);
                        Console.Write(ch);
                        System.Threading.Thread.Sleep(100); // 0.1초 정지
                        Console.SetCursorPosition(x, 12);
                        Console.Write(' ');
                        x++;
                    }
                    else
                    {
                        Console.SetCursorPosition(x, 12);
                        Console.Write(ch);
                        System.Threading.Thread.Sleep(100); // 0.1초 정지
                        Console.SetCursorPosition(x, 12);
                        Console.Write(' ');
                        x--;
                    }
                }
            }
        }

        // question02() 다른 풀이
        static void question22()
        {
            char ch = '#';
            int x = 0;
            int y = 12;
            Console.SetCursorPosition(0, 12);
            while (true)
            {
                for (int i = 0; i < 12; i++) //1
                {
                    Console.SetCursorPosition(x, y);
                    Console.Write(ch);
                    System.Threading.Thread.Sleep(100); // 0.1초 정지
                    Console.SetCursorPosition(x, y);
                    Console.Write(' ');
                    x++;
                    y--;
                }

                for (int i = 0; i < 12; i++) //2
                {
                    Console.SetCursorPosition(x, y);
                    Console.Write(ch);
                    System.Threading.Thread.Sleep(100); // 0.1초 정지
                    Console.SetCursorPosition(x, y);
                    Console.Write(' ');
                    x++;
                    y++;
                }

                for (int i = 0; i < 12; i++)//
                {
                    Console.SetCursorPosition(x, y);
                    Console.Write(ch);
                    System.Threading.Thread.Sleep(100); // 0.1초 정지
                    Console.SetCursorPosition(x, y);
                    Console.Write(' ');
                    x--;
                    y++;
                }

                for (int i = 0; i < 12; i++)
                {
                    Console.SetCursorPosition(x, y);
                    Console.Write(ch);
                    System.Threading.Thread.Sleep(100); // 0.1초 정지
                    Console.SetCursorPosition(x, y);
                    Console.Write(' ');
                    x--;
                    y--;
                }
            }
        }

        static void Main(string[] args)
        {
            //question01();
            //question02();
            question02_1();
            //question11();
            //question22();
        }
    }
}
