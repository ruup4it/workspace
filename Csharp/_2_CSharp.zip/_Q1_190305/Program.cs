﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _Q1_190305
{
    class Program
    {
        // 1. 구구단을 출력하되 1을 입력하면 홀수단만
        //    2를 입력하면 짝수단만 출력하라
        static void question1()
        {
            int mul = 0;
            Console.WriteLine("홀수단은 1 입력, 짝수단은 2 입력");
            string strMul = Console.ReadLine();
            mul = Int32.Parse(strMul);

            for (int i = 1; i <= 10; i++)
            {
                for (int j = 1; j <= 9; j++)
                {
                    if (mul % 2 == 0)
                    {
                        if (i % 2 == 0) { 
                        Console.WriteLine("{0} * {1} = {2}", i, j, i*j);
                        }
                    }
                    else if (mul % 2 != 0)
                    {
                        if (i % 2 != 0)
                        {
                            Console.WriteLine("{0} * {1} = {2}", i, j, i * j);
                        }
                    }


                }
                
            }
        }
        
        // question1 다른 방법
        // 1_2. 구구단을 출력하되 1을 입력하면 홀수단만
        //    2를 입력하면 짝수단만 출력하라
        static void question1_2()
        {
            int mul = 0;
            Console.WriteLine("홀수단은 1 입력, 짝수단은 2 입력");
            string strMul = Console.ReadLine();
            mul = Int32.Parse(strMul);

            int firstNum = 0; 
            if (mul == 1)
                firstNum = 1;
            else if (mul == 2)
                firstNum = 2;

            for (int i = firstNum; i <= 10; i+=2)
            {
                for (int j = 1; j <= 9; j++)
                {
                    Console.WriteLine("{0} * {1} = {2}", i, j, i * j);
                }
                Console.WriteLine();
            }
        }

        // 2. 0부터 1씩 증가한 값을 누적하여 더합니다.
        //    모두 더한값이 1000이 넘을 때 의 총합과
        //    더한 값을 구하세요.
        static void question2()
        {
            int num = 0;
            int sum = 0;
            
            do
            {
                sum += num;
                num++;
            } while (sum < 1000);

            Console.WriteLine("sum = {0}", sum);
        }

        // question2 다른방법
        // 2. 0부터 1씩 증가한 값을 누적하여 더합니다.
        //    모두 더한값이 1000이 넘을 때 의 총합과
        //    더한 값을 구하세요.
        static void question2_1()
        {
            int sum = 0;
            for (int i = 0; ; i++)
            {
                sum += i;
                if (sum > 1000)
                    break;
            }
            Console.WriteLine(sum);
            
        }

        // 3. 두 수를 입력받고 최소공배수를 구하세요.
        //  15 :  15 30 45 60  
        //  12 : 12 24 36 48 60
        //  60 % 15 = 0 
        //  60 % 12 = 0 
        static void question3()
        {

            int max = 0; // 입력 값들 중에 큰 값 
            int lcm = 0; // 최소공배수

            int num1 = 0; // 입력값1
            Console.WriteLine("첫 번째 수를 입력하세요");
            string strNum1 = Console.ReadLine();
            num1 = Int32.Parse(strNum1);

            int num2 = 0; // 입력값2
            Console.WriteLine("두 번째 수를 입력하세요");
            string strNum2 = Console.ReadLine();
            num2 = Int32.Parse(strNum2);

            if (num1 > num2)
                max = num1;
            else
                max = num2;

            /* for 문의 경우
            for (int i = max; ; i++)
            {
                if (i % num1 == 0 && i % num2 == 0)
                {
                    lcm = i;
                    break;
                }
            }
            */

            while (true)
            {
                if (max % num1 == 0 && max % num2 == 0)
                {
                    lcm = max;
                    break;
                }
                max++;
            }

            Console.WriteLine("{0} 과 {1} 의 최소공배수는 {2}", num1, num2, lcm);
        }

        // question3 다른 방법
        // 3. 두 수를 입력받고 최소공배수를 구하세요.
        //  15 :  15 30 45 60  
        //  12 : 12 24 36 48 60
        //  60 % 15 = 0 
        //  60 % 12 = 0 
        static void question3_2()
        {
            int num1 = 0, num2 = 0; // 입력값1, 2
            int lcm = 0; // 최소공배수

            Console.WriteLine("첫 번째 수를 입력하세요");
            num1 = Int32.Parse(Console.ReadLine());
            
            Console.WriteLine("두 번째 수를 입력하세요");
            num2 = Int32.Parse(Console.ReadLine());

            for (int i = 1; ; i++)
            {
                if (i % num1 == 0 && i % num2 == 0)
                {
                    Console.WriteLine("{0} 과 {1} 의 최소공배수는 {2} 입니다.", num1, num2, i);
                    break;
                }
            }
        }

        // question3 다른 방법 > 알고리즘 사용 수정 더 해야함 
        //static void question3_2()
        //{
        //    int big, small, mok, nmg, gcm, lcm;

        //    int num1 = 0;
        //    Console.WriteLine("첫 번째 수를 입력하세요");
        //    string strNum1 = Console.ReadLine();
        //    num1 = Int32.Parse(strNum1);

        //    int num2 = 0;
        //    Console.WriteLine("두 번째 수를 입력하세요");
        //    string strNum2 = Console.ReadLine();
        //    num2 = Int32.Parse(strNum2);

        //    if (num1 > num2)
        //    { 
        //        big = num1
        //        small = num2;
        //    }
        //    else
        //    { 
        //        big = num2
        //        small = num1;
        //    }

        //}



        // question3 다른 방법 

        static void question3_3()
        {
            int a = 0;
            int b = 0;
            int num = 0;
            // num%a==0 && num%b==0
            Console.WriteLine("첫 번째 수를 입력하세요");
            string strNum1 = Console.ReadLine();
            a = Int32.Parse(strNum1);


            Console.WriteLine("두 번째 수를 입력하세요");
            string strNum2 = Console.ReadLine();
            b = Int32.Parse(strNum2);
            num = a;
            for (; ; num++)
            {
                if (num % a == 0)
                {
                    if (num % b == 0)
                        break;
                }
            }
            Console.WriteLine("최소공배수는" + num);

        }

        // 4. 입력받은 숫자의 구구단을 출력하는데 역순으로 출력
        //    예) 3*9=27
        //        3*8=24...
        static void question4()
        {
            int mul = 0;
            Console.WriteLine("출력할 구구단의 단수를 입력하세요.");
            string strMul = Console.ReadLine();
            mul = Int32.Parse(strMul);

            for (int i = 9; i >= 1; i--)
            {
                Console.WriteLine("{0} * {1} = {2}", mul, i, mul * i);
            }
        }

        // 5. 정수 n을 입력받고 n!을 구하세요.(factorial)
        //    5를 입력한경우 1*2*3*4*5를 구하세요.
        static void question5()
        {
            int num = 0;
            int mul = 1;

            Console.WriteLine("팩토리얼을 구할 정수를 입력하세요");
            string strNum = Console.ReadLine();
            num = Int32.Parse(strNum);

            for (int i = 1; i <= num; i++)
            {
                if (i != num) 
                    Console.Write("{0} * ", i);
                else
                    Console.Write("{0}", i);
                mul *= i;
            }
            Console.Write(" = {0}", mul);
            Console.WriteLine();
        }
        
        // 001. 양의 정수를 입력받고 그 수만큼 "감사합니다"를 출력하세요
        static void question001()
        {
            int num = 0; // 입력변수

            Console.WriteLine("양의 정수를 입력해주세요.");
            string strNum = Console.ReadLine();
            num = Int32.Parse(strNum);

            for (int i = 0; i < num; i++) // 종료조건
            {
                Console.WriteLine("감사합니다. {0}", num - i);
            }
        }

        // 002. 양의 정수 입력받고 그 수만큼 3의 배수 출력하세요
        // 예를 들어 5를 입력받으면 3 6 9 12 15를 출력하면 됩니다
        static void question002()
        {
            int num = 0; // 입력변수

            Console.WriteLine("양의 정수를 입력해주세요.");
            string strNum = Console.ReadLine();
            num = Int32.Parse(strNum);

            for (int i = 1; i <= num; i++) // 종료조건
            {
                Console.WriteLine("{0}", i * 3);
            }


        }
        
        // 003. 입력받은 숫자의 구구단을 출력하세요
        //    예를 들어 3을 입력하면 
        //    3 x 1 = 3
        //    3 x 2 = 6
        //    ...
        //    3 x 9 = 27
        static void question003()
        {
            int num = 0; // 입력변수

            Console.WriteLine("양의 정수를 입력해주세요.");
            string strNum = Console.ReadLine();
            num = Int32.Parse(strNum);

            for (int i = 1; i <= 9; i++) // 종료조건
            {
                Console.WriteLine("{0} x {1} = {2}", num, i, num * i);
            }
        }

        // 004. 사용자로부터 정수를 입력받습니다.
        // 입력 받은 값을 계속 더합니다
        // 사용자가 0을 입력하면 합을 출력합니다
        // 프로그램을 종료합니다.
        static void question004()
        {
            int num = 1; // 입력변수
            int sum = 0;

            /* Do-While문
            do
            {
                Console.Write("양의 정수를 입력해주세요 (종료: 0 입력) : ");
                string strNum = Console.ReadLine();
                num = Int32.Parse(strNum);
                sum += num;
            } while (num > 0); // 종료조건
            */

            /* for문 */
            for (; num > 0;)
            {
                Console.Write("양의 정수를 입력해주세요 (종료: 0 입력) : ");
                string strNum = Console.ReadLine();
                num = Int32.Parse(strNum);
                sum += num;
            }

            Console.WriteLine("입력하신 수들의 합은 {0}입니다.", sum);
        }


        static void Main(string[] args)
        {
            //question1();
            //question1_2();
            //question2();
            //question2_1();
            //question3();
            //question3_2();
            //question3_3();
            //question4();
            //uestion5();


            //question001();
            //question002();
            //question003();
            //question004();
        }
    }
}
