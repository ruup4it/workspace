﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 구구단 전체 출력
namespace _29_for
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i=2; i<=9;i++) // 단 증가 ex) 2단, 3단, 4단 ...
            {
                for (int j=1; j<=9; j++) // 곱하는 수 증가 ex) 1, 2, 3, 4 ....
                {
                    Console.WriteLine("{0} x {1} = {2}", i, j, i * j);
                }
                Console.WriteLine();
            }
        }
    }
}
