﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 3. while문을 이용해서 1부터 10까지 합을 출력하세요
namespace _21_while
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 0;
            int result = 0;
            while (num < 10)
            {
                ++num;
                result = result + num;
                
                Console.WriteLine("{0}을 더합니다. 합계 : {1}", num, result);
            }
        }
    }
}
