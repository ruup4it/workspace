﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 2. 사용자한테 점수를 입력 받으세요
// 80점 이상이면 "합격"을 출력하세요
// 80점 미만이면 "불합격"을 출력하세요

namespace _8_if
{
    class Program
    {
        static void Main(string[] args)
        {
            int score = 0;

            Console.WriteLine("점수를 입력하세요");
            string strScore = Console.ReadLine();
            score = Int32.Parse(strScore);
            
            if (score >= 80)
                Console.WriteLine("합격입니다.");
            else
                Console.WriteLine("불합격입니다.");
        }
    }
}
