﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace areaTest
{
    class Program
    {
        public static void line()
        {
            Console.WriteLine("====================");
        }

        // 입력 받기
        public static void input()
        {
            while (true)
            {
                int selectNum = 0;

                Console.Write("입력: ");
                string strSelectNum = Console.ReadLine();
                selectNum = Int32.Parse(strSelectNum);

                if (selectNum == 1)
                {
                    Calculate();
                    break;
                }
                else if (selectNum == 2)
                {
                    print(3);
                    break;
                }
                else if (selectNum == 3)
                {
                    print(0);
                    break;
                }
                else
                {
                    Console.WriteLine("잘못된 숫자를 입력하셨습니다.");
                }
            }
        }


        // 넓이 계산
        public static void Calculate()
        {
            string selectStr = ""; // 선택값 초기화
            int horizontal = 0; // 가로값 초기화
            int Vertical = 0; // 세로값 초기화
            int result = 0; // 결과값 초기화

            line();
            Console.WriteLine("가로 길이를 입력하세요");
            Console.Write("입력: ");
            string strHorizontal = Console.ReadLine();
            horizontal = Int32.Parse(strHorizontal);
            Console.WriteLine("");
            
            Console.WriteLine("세로 길이를 입력하세요");
            Console.Write("입력: ");
            string strVertical = Console.ReadLine();
            Vertical = Int32.Parse(strVertical);
            Console.WriteLine("");

            Console.WriteLine("\"삼각형\" 또는 \"사각형\"을 입력하세요");

            while (true)
            {
                Console.Write("입력: ");
                selectStr = Console.ReadLine();
                Console.WriteLine("");
                if (selectStr == "삼각형") {
                    result = horizontal * Vertical / 2;
                    break;
                }
                else if (selectStr == "사각형") { 
                    result = horizontal * Vertical;
                    break;
                }
                else
                {
                    Console.WriteLine("!!!!!!!!!!!!!");
                    Console.WriteLine("잘못 입력하셨습니다.");
                    Console.WriteLine("\"삼각형\" 또는 \"사각형\"을 입력하세요");
                }

            }
            Console.WriteLine(selectStr + "의 넓이는 " + result + "입니다.");
            print(2);
        }

        // 출력하기
        public static void print(int caseNum)
        {
            if (caseNum == 0)
            {
                line();
                Console.WriteLine("###넓이 계산기###");
                line();
                Console.WriteLine("1. 넓이 계산 하기");
                Console.WriteLine("2. 종료하기");
                input();
            }
            
            else if (caseNum == 2)
            {
                line();
                Console.WriteLine("1. 계속하기");
                Console.WriteLine("2. 종료하기");
                Console.WriteLine("3. 메인화면으로");
                input();
            }


            else if (caseNum == 3)
            {
                line();
                Console.WriteLine("감사합니다.");
                line();
            }
        }


        static void Main(string[] args)
        {
            print(0);

            /*
            int cnt = 0;
            for (int i = 0; i < 11; i++)
            {

                if (i > 5)
                {

                    for (int k = 0; k < 5 - cnt; k++)
                    {
                        Console.Write(" * ");
                    }
                    cnt += 1;

                }
                else
                {
                    for (int j = 0; j < i + 1; j++)
                    {
                        Console.Write(" * ");
                    }
                }
                Console.WriteLine();
            }
            */
        }
    }
}
