﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//5. 가로와 세로를 입력 받아라
//    다시 "사각형" 또는 "삼각형"을 입력 받아라
//    "사각형"이면 사각형의 넓이를 (가로*세로)
//    "삼각형"이면 삼각형의 넓이를 출력하세요 (가로*세로/2)
namespace _11_Operator
{
    class Program
    {
        static void Main(string[] args)
        {
            string selectStr = ""; // 선택값 초기화
            int horizontal = 0; // 가로값 초기화
            int Vertical = 0; // 세로값 초기화
            int result = 0; // 결과값 초기화

            Console.WriteLine("가로 길이를 입력하세요");
            string strHorizontal = Console.ReadLine();
            horizontal = Int32.Parse(strHorizontal);
            Console.WriteLine("");

            Console.WriteLine("세로 길이를 입력하세요");
            string strVertical = Console.ReadLine();
            Vertical = Int32.Parse(strVertical);
            Console.WriteLine("");

            Console.WriteLine("\"삼각형\" 또는 \"사각형\"을 입력하세요");
            selectStr = Console.ReadLine();
            Console.WriteLine("");

            if (selectStr == "삼각형")
                result = horizontal * Vertical / 2;
            else if (selectStr == "사각형")
                result = horizontal * Vertical;
            
            Console.WriteLine( selectStr + "의 넓이는 " + result + "입니다.");
        }
    }
}
