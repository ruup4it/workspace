﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _Q0_190308
{
    class Program
    {
        // 5. 세개의 정수를 매개변수로 받아서
        //    가장 큰 수를 반환하는 메서드와
        //    가장 작은 수를 반환하는 메서드를 제작해서 사용해보세요

        // 정수 입력 받기
        static int inputNum(int order)
        {
            int num = 0;
            Console.Write("{0}번째 정수를 입력하세요 : ", order);
            num = Int32.Parse(Console.ReadLine());

            return num;
        }

        // 가장 큰 수를 반환하기
        static int maxNum(int num1, int num2, int num3)
        {
            int maxNum = 0;
            for (int i = 0; i < 3; i++)
            {
                if (num1 > maxNum)
                    maxNum = num1;
                if (num2 > maxNum)
                    maxNum = num2;
                if (num3 > maxNum)
                    maxNum = num3;
            }

            return maxNum;
        }

        // 가장 작은 수를 반환하기
        static int minNum(int num1, int num2, int num3)
        {
            int minNum = num1 + num2 + num3;
            for (int i = 0; i < 3; i++)
            {
                if (num1 <= minNum)
                    minNum = num1;
                if (num2 <= minNum)
                    minNum = num2;
                if (num3 <= minNum)
                    minNum = num3;
            }
            return minNum;
        }

        // 출력하기
        static void printNum(int num, string check)
        {
            switch (check)
            {
                case "max":
                    Console.WriteLine("가장 큰 수는 {0} 입니다.", num);
                    break;
                case "min":
                    Console.WriteLine("가장 작은 수는 {0} 입니다.", num);
                    break;
            }
        }

        static void Main(string[] args)
        {
            int num1 = 0, num2 = 0, num3 = 0, max = 0, min = 0;
            num1 = inputNum(1);
            num2 = inputNum(2);
            num3 = inputNum(3);
            max = maxNum(num1, num2, num3);
            min = minNum(num1, num2, num3);
            printNum(max,"max");
            printNum(min,"min");
        }
    }
}
