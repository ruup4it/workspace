﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//주석 적용 ctrl > k > c
//주석 해제 ctrl > k > u
// 3. 사용자한테 점수를 입력 받으세요
// 90점 이상이면 "A학점"을 출력하세요
// 80점 이상이면 "B학점"을 출력하세요
// 70점 이상이면 "C학점"을 출력하세요
// 60점 이상이면 "D학점"을 출력하세요
// 60점 미만이면 "F학점"을 출력하세요

namespace _9_if
{
    class Program
    {
        static void Main(string[] args)
        {
            int score = 0;
            string result = "";
            
            Console.WriteLine("점수를 입력하세요");
            string strScore = Console.ReadLine();
            score = Int32.Parse(strScore);
            
            if (score >= 90)
                result = "A학점";
            else if (score >= 80)
                result = "B학점";
            else if (score >= 70)
                result = "C학점";
            else if (score >= 60)
                result = "D학점";
            else
                result = "F학점";

            Console.WriteLine(result);
        }
    }
}
