﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 10명의 성적을 입력 받아라
// 10명의 성적 출력
// 총점 출력
// 평균 출력

namespace _36_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] scores = new int[10]; // 배열
            int sum = 0;
            int avg = 0;

            for(int i = 0; i < scores.Length; i++) // scores.Length = 10
            {
                Console.Write("{0} 번째 성적을 입력하세요", i+1);
                scores[i] = Int32.Parse(Console.ReadLine());
            }

            Console.WriteLine();

            for (int i = 0; i < scores.Length; i++)
            {
                Console.WriteLine("{0} 번째 성적은 {1} 입니다.",i+1,scores[i]);
                sum += scores[i];
            }

            avg = sum / scores.Length;

            Console.WriteLine();
            Console.WriteLine("총점은 {0} 입니다.\n평균은 {1} 입니다.", sum, avg);
        }
    }
}
