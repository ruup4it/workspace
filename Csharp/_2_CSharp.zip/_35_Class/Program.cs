﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* 클래스의 생성 목적
 * 1) 시대가 복잡해지므로 큰 단위가 요구됨 (정리를 용이)
 * 2) 프로그램에서는 반드시 변수와 함수가 결합됨
 *    - 어차피 둘 다 필요한 것이니까 하나로 묶자
 * 3) 문장 1형식 = 주어 + 동사
 *    프로그램 = 변수 + 메서드
 *    어느 정도 독립성 (캡슐화)
 */

// 클래스 : 사칙연산 담당 클래스
// 필드(변수) + 메서드 

// 메서드(행위)
// 1) 2개의 숫자와 연산자 입력
// 2) 사칙연산
// 3) 출력하기

// 2개의 숫자와 연산자를 입력 후 사칙연산 출력하기
namespace _35_Class
{
    class CalcManager
    {
        /**** 변수 영역 ****/
        int num0 = 0, num1 = 1;
        int result = 0;
        string op ="";


        /**** 메서드 영역 ****/
        // 입력 메서드
        public void InputTwoValue()
        {
            num0 = InputNum(1);
            num1 = InputNum(2);
            InputOp();
        }

        // 정수 입력 양식 메서드
        int InputNum(int order)
        {
            int num = 0;
            Console.Write("{0} 번째 숫자를 입력해주세요 : ", order);
            num = Int32.Parse(Console.ReadLine());
            return num;
        }

        // 연산자 입력 양식 메서드
        void InputOp()
        {
            Console.Write("연산자를 입력해주세요 : ");
            op = Console.ReadLine();
        }

        // 계산 메서드
        public void CalcArith()
        {
            switch (op)
            {
                case "+":
                    result = num0 + num1;
                    break;
                case "-":
                    result = num0 - num1;
                    break;
                case "*":
                    result = num0 * num1;
                    break;
                case "/":
                    result = num0 / num1;
                    break;
                default:
                    Console.WriteLine("연산자 잘못 입력");
                    break;
            }
        }

        // 결과값 출력 메서드
        public void PrintResult()
        {
            Console.WriteLine("연산의 결과값은 {0}입니다.", result);
        }
    }

    class Program
    {

        // 프로그램의 시작 
        static void Main(string[] args)
        {
            // 클래스     객체
            // 자료형     변수
            // 푸들       모모
            // int        num = 0;
            // int = 100; (x)

            CalcManager calcMgr = new CalcManager();
            calcMgr.InputTwoValue();
            calcMgr.CalcArith();
            calcMgr.PrintResult();


        }
        
    }
}
