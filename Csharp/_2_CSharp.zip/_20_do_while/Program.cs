﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* 반복문의 종류
 * while문
 * do~while문
 * for문
 * 위 3가지 반복문은 100% 호환가능
 */

namespace _20_do_while
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 0;     // 시작조건
            
            do
            {
                // 실행문
                Console.WriteLine("나무를 {0}번 찍었습니다", ++num);
            }while (num < 10); // 종료조건
        }
    }
}
