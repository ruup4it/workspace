﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//6. 사용자로부터 초를 입력받은 후
//  이 초를[시간, 분, 초]로 출력하는 메서드를 제작해서
//  사용해보세요
//  예를 들어 3672를 입력하면[1시간, 1분, 12초]를
//  출력하면 됩니다.

namespace _Q1_190308
{
    class Program
    {
        // 초 입력 받기
        static int inputSec()
        {
            int second = 0;
            Console.Write("시간(초)을 입력해주세요 : ");
            second = Int32.Parse(Console.ReadLine());

            return second;
        }

        // 계산하기
        static void calcTime(int second)
        {
            int hour = second / 3600; //1시간 = 60분 = 3600초
            second %= 3600;
            int minute = second / 60;
            second %= 60;
            Console.WriteLine("[{0}시, {1}분, {2}초]" , hour, minute, second);
        }
        
        static void Main(string[] args)
        {
            calcTime(inputSec());
        }
    }
}
