﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* while문 : ()내가 참인 조건일 때 계속 반복
 * while(참)
 * {
 *      실행문
 * }
 */

namespace _18_while
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 0;     // 시작조건
            while (num < 10) // 종료조건
            {
                // 실행문
                Console.WriteLine("나무를 {0}번 찍었습니다", ++num);
            }
        }
    }
}
