﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 4. while문을 이용해서 1부터 10까지 중에 짝수만 출력하세요
//    while문내에 조건문을 넣어주면 됨
//    짝수 조건 if(num % 2 == 0)

namespace _22_while
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 0;     // 시작조건
            while (num < 10) // 종료조건
            {
                ++num;
                if (num % 2 == 0)
                {
                    // 실행문
                    Console.WriteLine("{0}는 짝수입니다.", num);
                }
                
            }
        }
    }
}
