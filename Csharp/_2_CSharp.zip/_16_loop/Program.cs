﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _16_loop
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("나무를 1번 찍었습니다");
            Console.WriteLine("나무를 2번 찍었습니다");
            Console.WriteLine("나무를 3번 찍었습니다");
            Console.WriteLine("나무를 4번 찍었습니다");
            Console.WriteLine("나무를 5번 찍었습니다");
            Console.WriteLine("나무를 6번 찍었습니다");
            Console.WriteLine("나무를 7번 찍었습니다");
            Console.WriteLine("나무를 8번 찍었습니다");
            Console.WriteLine("나무를 9번 찍었습니다");
            Console.WriteLine("나무를 10번 찍었습니다");
        }
    }
}
