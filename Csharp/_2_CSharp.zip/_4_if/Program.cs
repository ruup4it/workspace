﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4_if
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 0;

            Console.WriteLine("숫자를 입력하세요");
            string strNum = Console.ReadLine();
            num = Int32.Parse(strNum);

            if(num == 100)
            {
                Console.WriteLine("입력하신 값은 100입니다.");
            }
            else
            {
                Console.WriteLine("입력하신 값은 100이 아닙니다.");
            }

            if (num > 100)
            {
                Console.WriteLine("입력하신 값은 100보다 큽니다.");
            }
        }
    }
}
