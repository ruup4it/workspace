﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 홀수만 또는 짝수만 출력
namespace _31_for
{
    class Program
    {
        // 1. 조건문을 사용해서 필터링
        /*
        static void Main(string[] args)
        {
            for (int i = 2; i <= 9; i++) // 단 증가 ex) 2단, 3단, 4단 ...
            {

                for (int j = 1; j <= 9; j++) // 곱하는 수 증가 ex) 1, 2, 3, 4 ....
                {
                    if (j % 2 == 0)
                    {
                        Console.Write("{0}x{1}={2} \t", i, j, i * j);
                    }
                }
                Console.WriteLine();
            }
        }
        */

        // 2. 초기값과 증가값을 이용해서 출력
        /*
        static void Main(string[] args)
        {
            for (int i = 2; i <= 9; i++) // 단 증가 ex) 2단, 3단, 4단 ...
            {

                for (int j = 2; j <= 9; j+=2) // 2씩 증가
                {
                    Console.Write("{0}x{1}={2} \t", i, j, i * j);
                }
                Console.WriteLine();
            }
        }
        */

        // 3. continue문을 이용해서 필터
        // programming에서 continue의 의미는
        // 위로 돌아가서 계속 진행해라
        static void Main(string[] args)
        {
            for (int i = 2; i <= 9; i++) // 단 증가 ex) 2단, 3단, 4단 ...
            {
                for (int j = 1; j <= 9; j ++) // 2씩 증가
                {
                    if (j % 2 == 1) //홀수일때
                        continue;
                    Console.Write("{0}x{1}={2} \t", i, j, i * j);
                }
                Console.WriteLine();
            }
        }
    }
}
