﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _Q1_190304
{
    class Program
    {
        // 1. 양의 정수를 입력받고 그 수만큼 "감사합니다"를 출력하세요
        static void question1()
        {
            int num = 0; // 입력변수

            Console.WriteLine("양의 정수를 입력해주세요.");
            string strNum = Console.ReadLine();
            num = Int32.Parse(strNum);

            while (num > 0) // 종료조건
            {
                Console.WriteLine("감사합니다. {0}", --num + 1);
            }
        }

        // 2. 양의 정수 입력받고 그 수만큼 3의 배수 출력하세요
        // 예를 들어 5를 입력받으면 3 6 9 12 15를 출력하면 됩니다
        static void question2()
        {
            int num = 0; // 입력변수
            int count = 0;

            Console.WriteLine("양의 정수를 입력해주세요.");
            string strNum = Console.ReadLine();
            num = Int32.Parse(strNum);

            while (num > 0) // 종료조건
            {
                num--;
                count++;
                Console.WriteLine("{0}", count * 3);
            }
        }


        // 3. 입력받은 숫자의 구구단을 출력하세요
        //    예를 들어 3을 입력하면 
        //    3 x 1 = 3
        //    3 x 2 = 6
        //    ...
        //    3 x 9 = 27
        static void question3()
        {
            int num = 0; // 입력변수
            int count = 0;

            Console.WriteLine("양의 정수를 입력해주세요.");
            string strNum = Console.ReadLine();
            num = Int32.Parse(strNum);

            while (count < 9) // 종료조건
            {
                count++;
                Console.WriteLine("{0} x {1} = {2}", num, count, num * count);
            }
        }

        // 4. 사용자로부터 정수를 입력받습니다.
        // 입력 받은 값을 계속 더합니다
        // 사용자가 0을 입력하면 합을 출력합니다
        // 프로그램을 종료합니다.
        static void question4()
        {
            int num = 1; // 입력변수
            int sum = 0;

            /* for문 사용
            for (; num!=0 ; sum += num)
            {
                Console.Write("양의 정수를 입력해주세요 (종료: 0 입력) : ");
                string strNum = Console.ReadLine();
                num = Int32.Parse(strNum);
            }
            */

            while (num != 0)
            {
                Console.Write("양의 정수를 입력해주세요 (종료: 0 입력) : ");
                string strNum = Console.ReadLine();
                num = Int32.Parse(strNum);
                sum += num;
            }

            Console.WriteLine("입력하신 수들의 합은 {0}입니다.", sum);
        }


        static void Main(string[] args)
        {
            //question1();
            //question2();
            //question3();
            question4();

        }
    }
}
