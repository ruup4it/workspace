﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _27_for
{
    class Program
    {
        static void Main(string[] args)
        {
            int dan = 0;
            string strDan = "";

            while (true)
            {
                Console.WriteLine("구구단 출력 숫자를 입력하세요");
                strDan = Console.ReadLine();
                dan = Int32.Parse(strDan);

                // break는 현재를 감싸는 반복문을 즉각 빠져나간다
                if (dan == -1)
                    break;

                for (int i = 1; i <= 9; i++)
                {
                    Console.WriteLine("{0}x{1}={2}", dan, i, dan * i);
                }
            }
        }
    }
}
