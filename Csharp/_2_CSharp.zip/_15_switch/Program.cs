﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// <switch~case문으로>
//<사용자한테 점수를 입력받으세요>
//   90점이상이면 "A학점"
//   80점이상이면 "B학점"
//   70점이상이면 "C학점"
//   60점이상이면 "D학점"
//   60점미만이면 "F학점"
namespace _15_switch
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 0;

            Console.WriteLine("점수를 입력하세요");
            string strNum = Console.ReadLine();
            num = Int32.Parse(strNum);

            switch(num/10)
            {
                case 10:
                case 9:
                    Console.WriteLine("A학점");
                    break;
                case 8:
                    Console.WriteLine("B학점");
                    break;
                case 7:
                    Console.WriteLine("C학점");
                    break;
                case 6:
                    Console.WriteLine("D학점");
                    break;
                default:
                    Console.WriteLine("F학점");
                    break;
            }

            /*
            if (num >= 90)
                Console.WriteLine("A학점입니다");
            else if (num >= 80)
                Console.WriteLine("B학점입니다");
            else if (num >= 70)
                Console.WriteLine("C학점입니다");
            else if (num >= 60)
                Console.WriteLine("D학점입니다");
            else //if (num < 60)
                Console.WriteLine("F학점입니다");
            */
        }
    }
}
