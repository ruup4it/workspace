﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace play
{
    class Program
    {
        static void Main(string[] args)
        {
            
            for (int i = 0; i < 11; i++)
            {
                if (i < 5)
                {
                    for (int j = 0; j < i + 1; j++)
                    {
                        Console.Write("*");
                    }
                }
                else
                {
                    for (int j = 0; j < 11 - i; j++)
                    {
                        Console.Write("*");
                    }
                }
                Console.WriteLine();
            }
            
        }
    }
}
