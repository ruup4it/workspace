﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/* 식당 클래스
 * 음식 종류들
 * 주문 요청
 * 음식 선택
 * 음식 전달 
 */
namespace _38_Class
{
    class Restaurant
    {

        /**** 변수 영역****/
        string[] foods = { "냉면", "칼국수", "쌀국수", "떡볶이", "순대", "튀김" };
        string selFood = "";
        /**** 메서드 영역****/
        // 음식을 보여준다.
        public void QuestionOrder()
        {
            Line();
            Console.WriteLine("########## 메뉴판 ##########");
            for (int i = 0; i < foods.Length; i++)
                Console.WriteLine("{0}. {1}", i+1, foods[i]);
        }

        // 음식을 선택한다.
        public void SelectFood()
        {
            Line();
            Console.WriteLine("어느 음식을 선택하시겠습니까? \n(번호를 입력하세요.)");
            Console.Write("입력:");
            int select = Int32.Parse(Console.ReadLine());
            selFood = foods[select - 1];
        }

        // 음식을 전달한다.
        public void DeliveryFood()
        {
            Line();
            Console.WriteLine("\" {0} \"이(가) 나왔습니다.", selFood);
            Console.WriteLine("맛있게 드세요 ^^");
            Line();
        }

        public void Line()
        {
            Console.WriteLine("============================");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Restaurant re = new Restaurant();
            re.QuestionOrder();
            re.SelectFood();
            re.DeliveryFood();
        }
    }
}
