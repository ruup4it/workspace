﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _Q0_190304
{
    class Program
    {

        // 1. while문을 이용해서 1부터 100까지 출력하세요
        static void question1()
        {
            int num = 0;
            while (num < 100)
            {
                ++num;
                Console.WriteLine(num);
            }
        }

        /* while문 : ()내가 참인 조건일 때 계속 반복
         * while(참)
         * {
         *      실행문
         * }
         */
        // 2. while문을 이용해서 10부터 20까지 출력하세요

        static void question2()
        {
            //// 1) ++num 의 경우
            //int num = 9;     // 시작조건
            //while (num < 20) // 종료조건
            //{
            //    Console.WriteLine("나무를 {0}번 찍었습니다", ++num);
            //}

            // 2) num++ 의 경우
            int num = 10;     // 시작조건
            while (num < 21) // 종료조건
            {
                Console.WriteLine("나무를 {0}번 찍었습니다", num++);
            }
        }

        // 3. while문을 이용해서 1부터 10까지 합을 출력하세요
        static void question3()
        {
            int num = 0;
            int result = 0;
            while (num < 10)
            {
                ++num;
                result += num;
                Console.WriteLine("{0}을 더합니다. 합계 : {1}", num, result);
            }
        }

        // 4. while문을 이용해서 1부터 10까지 중에 짝수만 출력하세요
        //    while문내에 조건문을 넣어주면 됨
        //    짝수 조건 if(num % 2 == 0)
        static void question4()
        {
            int num = 0;     // 시작조건
            while (num < 10) // 종료조건
            {
                ++num;
                if (num % 2 == 0)
                {
                    // 실행문
                    Console.WriteLine("{0}는 짝수입니다.", num);
                }
            }
        }

        static void Main(string[] args)
        {
            //question1();
            //question2();
            //question3();
            //question4();
        }
    }
}
