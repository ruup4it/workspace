﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 가로와 세로를 입력받아서 사각형의 넓이를 출력
namespace _10_Operator
{
    class Program
    {
        static void Main(string[] args)
        {
            int horizontal = 0; // 가로값 초기화
            int Vertical = 0; // 세로값 초기화
            int result = 0; // 결과값 초기화

            Console.WriteLine("가로 길이를 입력하세요");
            string strHorizontal = Console.ReadLine();
            horizontal = Int32.Parse(strHorizontal);
            Console.WriteLine("");

            Console.WriteLine("세로 길이를 입력하세요");
            string strVertical = Console.ReadLine();
            Vertical = Int32.Parse(strVertical);
            Console.WriteLine("");

            result = horizontal * Vertical;
            Console.WriteLine("사각형의 넓이는 " + result + "입니다.");
            Console.WriteLine("");

        }
    }
}
