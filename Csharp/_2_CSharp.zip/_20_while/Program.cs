﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* while문 : ()내가 참인 조건일 때 계속 반복
 * while(참)
 * {
 *      실행문
 * }
 */

 // 2. while문을 이용해서 10부터 20까지 출력하세요
namespace _20_while
{
    class Program
    {
        static void Main(string[] args)
        {
            //// 1) ++num 의 경우
            //int num = 9;     // 시작조건
            //while (num < 20) // 종료조건
            //{
            //    // 실행문
            //    Console.WriteLine("나무를 {0}번 찍었습니다", ++num);
            //}

            // 2) num++ 의 경우
            int num = 10;     // 시작조건
            while (num < 21) // 종료조건
            {
                // 실행문
                Console.WriteLine("나무를 {0}번 찍었습니다", num++);
            }

        }
    }
}
