﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 3단 출력

namespace _23_for
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int i = 1; i <= 9; i++)
            {
                Console.WriteLine("3 x " + i + " = " + 3 * i);
            }
        }
    }
}
