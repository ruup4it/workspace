﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _Q0_190305
{
    class Program
    {
        //1. for문을 이용해서 1부터 100까지 출력하세요
        static void question1()
        {
            for (int i = 1; i <= 100; i++) // 종료조건
            {
                Console.WriteLine(i);
            }
        }

        //2. for문을 이용해서 10부터 20까지 출력하세요
        static void question2()
        {
            for (int i = 10; i <= 20; i++) // 종료조건
            {
                Console.WriteLine(i);
            }
        }

        //3. for문을 이용해서 1부터 10까지 합을 출력하세요
        static void question3()
        {
            int sum = 0;
            for (int i = 1; i <= 10; ++i) // 종료조건
            {
                sum += i;
                //Console.WriteLine("{0}을 더합니다. 합계 : {1}", i, sum);
            }
            Console.WriteLine(sum);
        }

        //4. for문을 이용해서 1부터 10까지 중에 짝수만 출력하세요
        //   for문내에 조건문을 넣어주면 됨
        //   짝수 조건 if(num % 2 == 0)
        static void question4()
        {
            for (int i = 1; i <= 10; i++) // 종료조건
            {
                if (i % 2 == 0)
                {
                    Console.WriteLine("{0}는 짝수입니다.", i);
                }
            }
        }

        static void Main(string[] args)
        {
            //question1();
            //question2();
            //question3();
            //question4();
        }
    }
}
