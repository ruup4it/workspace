﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 1. 사용자한테 점수를 입력 받으세요
// 80점 이상이면 "합격"을 출력하세요

namespace _7_if
{
    class Program
    {
        static void Main(string[] args)
        {
            int score = 0;

            Console.WriteLine("점수를 입력하세요");
            string strScore = Console.ReadLine();
            score = Int32.Parse(strScore);

            Console.WriteLine("입력하신 점수는 " + score + "입니다.");

            if (score >= 80)
                Console.WriteLine("합격입니다.");
        }
    }
}
