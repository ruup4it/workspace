﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* <문제>
 * swtich~case문을 이용해서 출력하세요
 * "봄", "여름", "가을", "겨울"중에 하나를 입력받아라
 * 봄 -> "꽃이 핀다"
 * 여름 -> "꽃이 자라난다"
 * 가을 -> "꽃이 진다"
 * 겨울 -> "꽃이 숨어있다"
 */

namespace _14_switch
{
    class Program
    {
        static void Main(string[] args)
        {
            string season = "";

            Console.WriteLine("계절 입력(봄,여름,가을,겨울 중 1개");
            season = Console.ReadLine();

            switch(season)
            {
                case "봄":
                    Console.WriteLine("꽃이 핀다");
                    break;
                case "여름":
                    Console.WriteLine("꽃이 자란다");
                    break;
                case "가을":
                    Console.WriteLine("꽃이 진다");
                    break;
                case "겨울":
                    Console.WriteLine("꽃이 숨는다");
                    break;
                default:
                    Console.WriteLine("잘 못 입력");
                    break;
            }
        }
    }
}
