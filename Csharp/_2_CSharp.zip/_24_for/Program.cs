﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 숫자를 입력받고 
// for문으로 해당 숫자의 구구단 부분을 출력하세요

namespace _24_for
{
    class Program
    {
        static void Main(string[] args)
        {
            int dan = 0;
            string strDan = "";

            Console.WriteLine("구구단 출력 숫자를 입력하세요");
            strDan = Console.ReadLine();
            dan = Int32.Parse(strDan);

            for(int i=1;i<=9;i++)
            {
                //Console.WriteLine(dan + "x" + i + "=" + dan * i);
                Console.WriteLine("{0}x{1}={2}", dan, i, dan * i);
            }
        }
    }
}
