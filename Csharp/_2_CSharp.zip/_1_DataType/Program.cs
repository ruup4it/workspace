﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1_DataType
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 100;
            double dnum = 3.14;
            char ch = 'a';
            string name = "홍길동";
            Console.WriteLine("num 의 값은 " + num);
            Console.WriteLine("dnum 의 값은 " + dnum);
            Console.WriteLine("ch 의 값은 " + ch);
            Console.WriteLine("name 의 값은 " + name);
        }
    }
}
