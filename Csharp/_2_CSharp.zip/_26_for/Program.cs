﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _26_for
{
    class Program
    {
        static void Main(string[] args)
        {
            int dan = 0;
            string strDan = "";

            while (dan != -1)
            {
                Console.WriteLine("구구단 출력 숫자를 입력하세요");
                strDan = Console.ReadLine();
                dan = Int32.Parse(strDan);

                if (dan != -1)
                {
                    for (int i = 1; i <= 9; i++)
                    {
                        Console.WriteLine("{0}x{1}={2}", dan, i, dan * i);
                    }
                }
            }
        }
    }
}
