﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* <주소록 프로젝트>
 * 1) 시작 클래스
 * 2) 주소 클래스 (Model)            - Data
 * 3) 메뉴 클래스 (View)             - 화면
 * 4) 주소록 관리 클래스 (Controller) - 비즈니스 로직
 * 
 * 이름, 전화번호, 주소를 입력/ 검색/ 변경/ 삭제/ 전체출력을 한다.
 * * 기능 정의
 * 0) 메뉴 반복
 * void MainLoop();
 * 1) 메뉴 출력
 * void PrintMenu();
 * 2) 메뉴 선택
 * int GetSelectMenu();
 * 3) 주소 정보 입력 (이름, 전화, 주소)
 * void InputAddress();
 * 4) 주소 정보 검색 (이름으로 검색)
 * void SearchAddress();
 * 5) 주소 정보 변경 (이름으로 변경)
 * void UpdateAddress();
 * 6) 주소 정보 삭제 (이름으로 검색 후 삭제)
 * void DeleteAddress();
 * 7) 주소 정보 전체 출력
 * void PrintAllAddress();
 * 8) 프로그램 종료
 * void ProgramExit();
 * 9) 화면 지우기
 * void ClearView();
 */
namespace _40_AddressClassProject
{
    /**** 주소 클래스 ****/
    class Address
    {
        public string name;
        public string phone;
        public string address;
    }

    /**** 메뉴 클래스 ****/
    class Menu
    {
        /**** 메뉴 반복 ****/
        public void MainLoop()
        {
            AddressManager mngr = new AddressManager();
            while (true)
            {
                ClearView();
                PrintMenu();
                int sel = GetSelectMenu();
                switch (sel)
                {
                    case 1:
                        mngr.InputAddress();
                        break;
                    case 2:
                        mngr.SearchAddress();
                        break;
                    case 3:
                        mngr.UpdateAddress();
                        break;
                    case 4:
                        mngr.DeleteAddress();
                        break;
                    case 5:
                        mngr.PrintAllAddress();
                        break;
                    case 6:
                        ProgramExit();
                        break;
                    default:
                        Console.WriteLine("잘못 입력하셨습니다.");
                        break;
                }
            }
        }

        /**** 메뉴 출력 ****/
        public void PrintMenu()
        {
            Line();
            Console.WriteLine("###주소록 프로젝트###");
            Line();
            Console.WriteLine("1. 주소 입력");
            Console.WriteLine("2. 주소 검색");
            Console.WriteLine("3. 주소 변경");
            Console.WriteLine("4. 주소 삭제");
            Console.WriteLine("5. 주소 전체 출력");
            Console.WriteLine("6. 프로그램 종료");
            Line();
        }

        /**** 메뉴 선택 ****/
        public int GetSelectMenu()
        {
            int sel = -1;
            Console.Write("입력 : ");
            sel = Int32.Parse(Console.ReadLine());
            return sel;
        }

        /**** 프로그램 종료 ****/
        public void ProgramExit()
        {
            Console.WriteLine("이용해주셔서 감사합니다.");
            Line();
            Environment.Exit(0);
        }

        /**** 화면 지우기 ****/
        public void ClearView()
        {
            Console.Clear();
        }

        public void Line()
        {
            Console.WriteLine("========================");

        }
    }

    /**** 주소록 관리 클래스 ****/
    class AddressManager
    {
        // 주소록 저장 공간
        // 최초에 10개 공간 할당
        // 이후에는 알아서 증가
        List<Address> arrayAddress = new List<Address>(10);
        

        /**** 주소 정보 입력 (이름, 전화, 주소) ****/
        public void InputAddress()
        {
            Menu menu = new Menu();
            menu.ClearView();
            Console.Write("이름을 입력하세요. \n입력 : ");
            string name = Console.ReadLine();
            Console.Write("전화번호를 입력하세요. \n입력 : ");
            string phone = Console.ReadLine();
            Console.Write("주소를 입력하세요. \n입력 : ");
            string address = Console.ReadLine();

            Address addr = new Address();
            addr.name = name;
            addr.phone = phone;
            addr.address = address;
            arrayAddress.Add(addr); // 저장소에 저장 
        }

        /**** 주소 정보 검색 (이름으로 검색) ****/
        public void SearchAddress()
        {
            Menu menu = new Menu();
            menu.ClearView();
            Console.WriteLine("이름을 입력하세요.");
            Console.Write("입력 : ");
            string name = Console.ReadLine();

            for (int i = 0; i < arrayAddress.Count; i++)
            {
                if (name == arrayAddress[i].name)
                {
                    Console.WriteLine("========== {0} ==========", i + 1);
                    Console.WriteLine("이름 : {0}", arrayAddress[i].name);
                    Console.WriteLine("전화번호 : {0}", arrayAddress[i].phone);
                    Console.WriteLine("주소 : {0}", arrayAddress[i].address);
                    Console.WriteLine("=======================");
                    break;
                }
            }
            Console.ReadKey();
        }

        /**** 주소 정보 변경 (이름으로 변경) ****/
        public void UpdateAddress()
        {
            Menu menu = new Menu();
            menu.ClearView();
            Console.WriteLine("이름을 입력하세요.");
            Console.Write("입력 : ");
            string name = Console.ReadLine();

            for (int i = 0; i < arrayAddress.Count; i++)
            {
                if (name == arrayAddress[i].name)
                {
                    Console.WriteLine("========== {0} ==========", i + 1);
                    Console.WriteLine("이름 : {0}", arrayAddress[i].name);
                    Console.WriteLine("전화번호 : {0}", arrayAddress[i].phone);
                    Console.WriteLine("주소 : {0}", arrayAddress[i].address);
                    Console.WriteLine("=======================");

                    Console.Write("이름 입력 : ");
                    string uName = Console.ReadLine();

                    Console.Write("전화번호 입력 : ");
                    string phone = Console.ReadLine();

                    Console.Write("주소 입력 : ");
                    string address = Console.ReadLine();

                    arrayAddress[i].name = uName;
                    arrayAddress[i].phone = phone;
                    arrayAddress[i].address = address;
                    break;
                }
            }
            Console.ReadKey();
        }

        /**** 주소 정보 삭제 (이름으로 검색 후 삭제) ****/
        public void DeleteAddress()
        {
            Menu menu = new Menu();
            menu.ClearView();
            Console.WriteLine("이름을 입력하세요.");
            Console.Write("입력 : ");
            string name = Console.ReadLine();

            for (int i = 0; i < arrayAddress.Count; i++)
            {
                if (name == arrayAddress[i].name)
                {
                    Console.WriteLine("========== {0} ==========", i + 1);
                    Console.WriteLine("이름 : {0}", arrayAddress[i].name);
                    Console.WriteLine("전화번호 : {0}", arrayAddress[i].phone);
                    Console.WriteLine("주소 : {0}", arrayAddress[i].address);
                    Console.WriteLine("=======================");

                    Console.WriteLine("정말로 삭제하시겠습니까? (y/n)");
                    string yesOrNo = Console.ReadLine();
                    if (yesOrNo == "y")
                        arrayAddress.RemoveAt(i);
                    break;
                }
            }
            Console.ReadKey();
        }

        /**** 주소 정보 전체 출력 ****/
        public void PrintAllAddress()
        {
            Menu menu = new Menu();
            menu.ClearView();
            for (int i = 0; i < arrayAddress.Count; i++)
            {
                Console.WriteLine("========== {0} ==========", i + 1);
                Console.WriteLine("이름 : {0}", arrayAddress[i].name);
                Console.WriteLine("전화번호 : {0}", arrayAddress[i].phone);
                Console.WriteLine("주소 : {0}", arrayAddress[i].address);
                Console.WriteLine("=======================");
            }

            Console.ReadKey(); // 입력 받기 전까지 대기 상태
        }
    }
    
    class Program
    {
        static void Main(string[] args)
        {
            Menu menu = new Menu();
            
            menu.MainLoop();
        }
    }
}
