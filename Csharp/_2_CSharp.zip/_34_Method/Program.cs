﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* 메서드를 만드는 목적
 * 1) 복잡한 프로그램을 적절한 단위로 분산
 *    그룹핑, 관리용이, 정리(가독성이 좋아짐)
 * 2) 반복적인 코드를 줄일 때
 *    메서드 이름만으로 호출 가능
 */

// 2개의 숫자와 연산자를 입력 후 사칙연산 출력하기
namespace _34_Method
{
    class Program
    {
        /*
       // 결과값 출력
       static void printResult(int result)
       {
           Console.WriteLine("연산의 결과값은 {0}입니다.", result);
       }

       // 입력
       static void input()
       {
           int num0, num1 = 1;
           string op = "";

           Console.Write("첫번째 숫자 입력: ");
           num0 = Int32.Parse(Console.ReadLine());

           Console.Write("두번째 숫자 입력: ");
           num1 = Int32.Parse(Console.ReadLine());

           Console.Write("연산자 입력: ");
           op = Console.ReadLine();

           CalcArith(num0, num1, op);
       }

       // 계산
       static void CalcArith(int num0, int num1, string op) {
           int result = 0;
           switch (op)
           {
               case "+":
                   result = num0 + num1;
                   break;
               case "-":
                   result = num0 - num1;
                   break;
               case "*":
                   result = num0 * num1;
                   break;
               case "/":
                   result = num0 / num1;
                   break;
               default:
                   Console.WriteLine("연산자 잘못 입력");
                   break;
           }
           // 이 메서드를 호출한 곳으로 반환
           printResult(result);
       }

       // 프로그램의 시작 
       static void Main(string[] args)
       {
           input();
       }
       
        */
        static int inputNum(string order)
        {
            int num = 0;
            Console.Write("{0} 번째 숫자를 입력해주세요 : ", order);
            num = Int32.Parse(Console.ReadLine());
            return num;
        }

        static string inputOp()
        {
            string op;
            Console.Write("연산자를 입력해주세요 : ");
            op = Console.ReadLine();
            return op;
        }

        // 결과값 출력
        static void printResult(int result)
        {
            Console.WriteLine("연산의 결과값은 {0}입니다.", result);
        }
        
        // 계산
        static int CalcArith(int num0, int num1, string op)
        {
            int result = 0;
            switch (op)
            {
                case "+":
                    result = num0 + num1;
                    break;
                case "-":
                    result = num0 - num1;
                    break;
                case "*":
                    result = num0 * num1;
                    break;
                case "/":
                    result = num0 / num1;
                    break;
                default:
                    Console.WriteLine("연산자 잘못 입력");
                    break;
            }
            // 이 메서드를 호출한 곳으로 반환
            return result;
        }

        // 프로그램의 시작 
        static void Main(string[] args)
        {
            int num0 = inputNum("1");
            int num1 = inputNum("2");
            string op = inputOp();
            int result = CalcArith(num0, num1, op);
            printResult(result);
        }
        
    

    }
}
